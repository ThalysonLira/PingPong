package com.example.labmacmini06.motorgrafico;

import android.os.Bundle;
import com.example.labmacmini06.motorgrafico.AndGraph.AGActivityGame;
import com.example.labmacmini06.motorgrafico.Cenas.CenaAbertura;
import com.example.labmacmini06.motorgrafico.Cenas.CenaConfiguracoes;
import com.example.labmacmini06.motorgrafico.Cenas.CenaCreditos;
import com.example.labmacmini06.motorgrafico.Cenas.CenaExecucao;
import com.example.labmacmini06.motorgrafico.Cenas.CenaMenu;

// AGActivityGame contem todas as classes dos antigos projetos (Acelerometro, touch, render e etc)
public class Principal extends AGActivityGame {

    CenaAbertura abertura = null;
    CenaConfiguracoes configuracoes = null;
    CenaCreditos creditos = null;
    CenaMenu menu = null;
    CenaExecucao execucao = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicia o motor (da a partida)
// O false se refere ao acelerometro, caso o aparelho contenha acelerometro basta enviar true (para habilitar)
        this.init(this, false);

// O gerente da cena irá controlar qual cena está sendo exibida no momento
//        abertura = new CenaAbertura(getGameManager());
        menu = new CenaMenu(getGameManager());
        execucao = new CenaExecucao(getGameManager());
        configuracoes = new CenaConfiguracoes(getGameManager());
        creditos = new CenaCreditos(getGameManager());


//        getGameManager().addScene(abertura);   // Registra a cena no gerenciador
        getGameManager().addScene(menu);
        getGameManager().addScene(execucao);
        getGameManager().addScene(configuracoes);
        getGameManager().addScene(creditos);

    }
}