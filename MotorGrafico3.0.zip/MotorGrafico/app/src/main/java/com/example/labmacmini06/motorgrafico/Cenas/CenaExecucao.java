package com.example.labmacmini06.motorgrafico.Cenas;

import com.example.labmacmini06.motorgrafico.AndGraph.AGGameManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGInputManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGScene;
import com.example.labmacmini06.motorgrafico.AndGraph.AGScreenManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGSprite;
import com.example.labmacmini06.motorgrafico.R;

/**
 * Created by labmacmini06 on 20/11/2018.
 */

public class CenaExecucao extends AGScene {
    AGSprite gato;

    public CenaExecucao(AGGameManager manager){
        super(manager);
    }

    @Override
    public void init() {
        // É chamado toda vez que uma cena é apresentada
        setSceneBackgroundColor(0,0,0);
        this.criarImagens();
    }

    @Override
    public void restart() {
        // É chamado na volta de uma interrupção (alarme, ligação)
    }

    @Override
    public void stop() {
        // É chamado quando ocorrer a interrupção
    }

    @Override
    public void loop() {
        // Corresponde ao onDrawFrame (controla a lógica da cena)

        if(AGInputManager.vrTouchEvents.backButtonClicked()) {
            vrGameManager.setCurrentScene(0);
            return;
        }
    }

    private void criarImagens(){
        // Adicionando imagem de fundo
        gato = createSprite(R.mipmap.gato,
                2, 4);

        gato.setScreenPercent(75,25);

        gato.vrPosition.setX(AGScreenManager.iScreenWidth / 2);
        gato.vrPosition.setY(AGScreenManager.iScreenHeight / 2);

        gato.addAnimation(25,true,0,7);
    }
}
