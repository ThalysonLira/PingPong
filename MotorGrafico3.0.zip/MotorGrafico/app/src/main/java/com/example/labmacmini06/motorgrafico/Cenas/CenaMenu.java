package com.example.labmacmini06.motorgrafico.Cenas;

import com.example.labmacmini06.motorgrafico.AndGraph.AGGameManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGInputManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGScene;
import com.example.labmacmini06.motorgrafico.AndGraph.AGScreenManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGSprite;
import com.example.labmacmini06.motorgrafico.R;

public class CenaMenu extends AGScene {
//    AGTimer intervaloTempo = null;
    int controle = 1;
    AGSprite wallpaper, btPlay, btConfig, btInfo;

    public CenaMenu(AGGameManager manager){
        super(manager);
    }

    @Override
    public void init() {
        // É chamado toda vez que uma cena é apresentada
//        setSceneBackgroundColor(1,0,0);
//        intervaloTempo = new AGTimer(3000);

        this.criarImagens();
    }

    @Override
    public void restart() {
        // É chamado na volta de uma interrupção (alarme, ligação)

    }

    @Override
    public void stop() {
        // É chamado quando ocorrer a interrupção

    }

    @Override
    public void loop() {
        // Corresponde ao onDrawFrame (controla a lógica da cena)

//        intervaloTempo.update();

//        if(AGInputManager.vrTouchEvents.screenClicked() || intervaloTempo.isTimeEnded()){
//            if(controle == 1){
//                vrGameManager.setCurrentScene(2);
//                controle *= -1;
//            }
//            else if(controle == -1){
//                vrGameManager.setCurrentScene(3);
//                controle *= -1;
//            }
//        }

        if(AGInputManager.vrTouchEvents.screenClicked()){
            if(btPlay.collide(AGInputManager.vrTouchEvents.getLastPosition())) {
                vrGameManager.setCurrentScene(1);
                return;
            }
            else if(btConfig.collide(AGInputManager.vrTouchEvents.getLastPosition())) {
                vrGameManager.setCurrentScene(2);
                return;
            }
            else if(btInfo.collide(AGInputManager.vrTouchEvents.getLastPosition())) {
                vrGameManager.setCurrentScene(3);
                return;
            }
        }
    }

    private void criarImagens(){
        // Adicionando imagem de fundo
        wallpaper = createSprite(R.mipmap.pingpong_wallpaper,
                1, 1);

        wallpaper.setScreenPercent(100,100);

        wallpaper.vrPosition.setX(AGScreenManager.iScreenWidth / 2);
        wallpaper.vrPosition.setY(AGScreenManager.iScreenHeight / 2);


        // Adicionando botao jogar
        btPlay = createSprite(R.mipmap.bt_play,
                1, 1);

        btPlay.setScreenPercent(50,35);

        btPlay.vrPosition.setX(AGScreenManager.iScreenWidth / 2);
        btPlay.vrPosition.setY(AGScreenManager.iScreenHeight / 2);


        // Adicionando botao configuracao
        btConfig = createSprite(R.mipmap.bt_configuration,
                1, 1);

        btConfig.setScreenPercent(16,10);

        btConfig.vrPosition.setX((float) (AGScreenManager.iScreenWidth / 1.1));
        btConfig.vrPosition.setY((float) (AGScreenManager.iScreenHeight / 1.06));


        // Adicionando botao informacao
        btInfo = createSprite(R.mipmap.bt_information,
                1, 1);

        btInfo.setScreenPercent(15,9);

        btInfo.vrPosition.setX((float) (AGScreenManager.iScreenWidth / 11));
        btInfo.vrPosition.setY((float) (AGScreenManager.iScreenHeight / 1.06));
    }
}