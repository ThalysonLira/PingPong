package com.example.labmacmini06.motorgrafico.Cenas;

import com.example.labmacmini06.motorgrafico.AndGraph.AGGameManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGInputManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGScene;

public class CenaCreditos  extends AGScene {
    public CenaCreditos(AGGameManager manager){
        super(manager);
    }

    @Override
    public void init() {
        // É chamado toda vez que uma cena é apresentada
        setSceneBackgroundColor(1,0,0);
    }

    @Override
    public void restart() {
        // É chamado na volta de uma interrupção (alarme, ligação)

    }

    @Override
    public void stop() {
        // É chamado quando ocorrer a interrupção

    }

    @Override
    public void loop() {
        // Corresponde ao onDrawFrame (controla a lógica da cena)

        if(AGInputManager.vrTouchEvents.backButtonClicked()) {
            vrGameManager.setCurrentScene(0);
            return;
        }
    }
}