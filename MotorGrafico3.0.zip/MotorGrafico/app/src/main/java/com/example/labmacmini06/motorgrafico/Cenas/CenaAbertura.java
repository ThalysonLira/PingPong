package com.example.labmacmini06.motorgrafico.Cenas;

import com.example.labmacmini06.motorgrafico.AndGraph.AGGameManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGInputManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGScene;
import com.example.labmacmini06.motorgrafico.AndGraph.AGScreenManager;
import com.example.labmacmini06.motorgrafico.AndGraph.AGSprite;
import com.example.labmacmini06.motorgrafico.AndGraph.AGTimer;
import com.example.labmacmini06.motorgrafico.R;

public class CenaAbertura extends AGScene{
    AGTimer intervaloTempo = null;
    AGSprite escudo = null;

      public CenaAbertura(AGGameManager manager){
          super(manager);
      }

    @Override
    public void init() {
        // É chamado toda vez que uma cena é apresentada

//        intervaloTempo = new AGTimer(3000);
//        setSceneBackgroundColor(1,1,0);

        escudo = createSprite(R.mipmap.cap_maior,
                1, 1);

        escudo.setScreenPercent(75, 47);

        escudo.vrPosition.setX(AGScreenManager.iScreenWidth / 2);
        escudo.vrPosition.setY(AGScreenManager.iScreenHeight / 2);
    }

    @Override
    public void restart() {
        // É chamado na volta de uma interrupção (alarme, ligação)

    }

    @Override
    public void stop() {
        // É chamado quando ocorrer a interrupção

    }

    @Override
    public void loop() {
//          intervaloTempo.update();

        // Corresponde ao onDrawFrame (controla a lógica da cena)
//        if(AGInputManager.vrTouchEvents.screenClicked() || intervaloTempo.isTimeEnded()){
//            vrGameManager.setCurrentScene(1);
//        }

//        if(AGInputManager.vrTouchEvents.backButtonClicked()){
//            vrGameManager.vrActivity.finish();
//        }
    }
}